# ROS Cellulo API - Application Package

## Overview

This is the main package of the ROS Cellulo API.

![Rviz Cellulo](/doc/fig.png)

#### Dependencies

- [Robot Operating System (ROS)],
- [Qt] (QT_LIBRARIES Gui, Widgets , Quick , Bluetooth)


#### Building

To build from source, clone the latest version from this repository into your catkin workspace and compile the package using

```
cd catkin_ws/src
git clone https://c4science.ch/diffusion/5556/ros_cellulo.git
cd ../catkin_make
```
## Usage

To run a main node of Cellulo:
```
roslaunch ros_cellulo ros_cellulo.launch mac_adr:=xx_xx
```
where xx\_xx represents the 4 digits written on the tag on the robot where the 2 points ":" is replaced by "\_"


## Nodes

### ros_cellulo_node

Provides the ROS interafce for the cellulo robot

#### Published Topics

* **`/cellulo_node_xx_xx/TouchKey`** ([ros_cellulo/cellulo_touch_key])

	Array of 6 booleans published when one touch key is pressed
* **`/cellulo_node_xx_xx/LongTouchKey`** ([ros_cellulo/cellulo_touch_key])

	Array of 6 booleans published when one touch key is long pressed
* **`/cellulo_node_xx_xx/Kidnapped`** ([ros_cellulo/cellulo_kidnapped_msg])

	Message with the cellulo address and the kidnapped value. Published when kidnapped state change on the robot.
* **`/cellulo_node_xx_xx/ConnectionStatus`** ([std_msgs/Int8])

	Connection status, published when ConnectionStatus is changed.
* **`/cellulo_node_xx_xx/LocalAdapterAdress`** ([std_msgs/String])

	Local Adapter Address, published when it is changed  
* **`/cellulo_node_xx_xx/autoConnect`** ([std_msgs/Bool])

	autoConnect state of the cellulo, published when it is changed

* **`/cellulo_node_xx_xx/macAddress`** ([std_msgs/String])

	Mac Address, published when it is changed

* **`/cellulo_node_xx_xx/BatteryState`** ([std_msgs/Int8])

	Battery State, published when it is changed
* **`/cellulo_node_xx_xx/Gesture`** ([std_msgs/Int8])

	Gesture, published when it is changed

* **`/cellulo_node_xx_xx/lastTimestamp`** ([std_msgs/Int8])

	Last time stamp, published when it is changed

* **`/cellulo_node_xx_xx/framerate`** ([std_msgs/Float32])

	Frame rate,  published when it is changed
* **`/cellulo_node_xx_xx/cameraImageProgress`** ([std_msgs/Float32])

	Camera image progess, published when it is changed
* **`/cellulo_node_xx_xx/Vx`** ([std_msgs/Float64])

	Velocity Vx, published when it is changed
* **`/cellulo_node_xx_xx/Vy`** ([std_msgs/Float64])

	Velocity Vy, published when it is changed

* **`/cellulo_node_xx_xx/w`** ([std_msgs/Float64])

	rotational velocity w, published when it is changed

* **`/cellulo_node_xx_xx/poseVelControlEnable`** ([std_msgs/Bool])

	Flag poseVelControlEnable, published when it is changed

* **`/cellulo_node_xx_xx/poseVelControlPeriod`** ([std_msgs/Int32])

	poseVelControlPeriod, published when it is changed

* **`/cellulo_node_xx_xx/destination_reached`** ([std_msgs/Bool])

	destination_reached, published when destimation of tracking is reached.
* **`/cellulo_node_xx_xx/visualization_marker_traj`** ([visualization_msgs/Marker])

	Visualization marker for the trajectory (for rviz)
* **`/cellulo_node_xx_xx/visualization_marker_robot`** ([visualization_msgs/Marker])

	Visualization marker for the robot (for rviz)

* **`A TransformBroadcaster`** ([Frame: /xx:xx Parent: /paper_world])

	Broadcasts the robots position, each time it is changed (as a slot for the signal poseChanged)



#### Subscribed Topics

* **`/cellulo_node_xx_xx/Set_Pose_Vel`** ([ros_cellulo/cellulo_pose_velocity])

	Set Position and Velocity of the robot

* **`/cellulo_node_xx_xx/Set_Pose`** ([const geometry_msgs/Point])

	Set Position of the robot to (Point.x, Point.y) and Point.z indicates the desired velocity to reach the goal position
* **`/cellulo_node_xx_xx/Set_Visual_Effect`** ([ros_cellulo/cellulo_visual_effect])

	Sets the visual effect of the robot.
* **`/cellulo_node_xx_xx/Reset`** ([std_msgs/Empty])

	Resets the robot
* **`/cellulo_node_xx_xx/write_traj_back`** ([nav_msgs/Path])

	Follow the given path.
* **`/cellulo_node_xx_xx/follow_direction`** ([geometry_msgs/Point])

	Follow a given direction with a given speed (i.e. sets Vx and Vy)
* **`/cellulo_node_xx_xx/Fill_Path`** ([geometry_msgs/Point])

	Append apoint to the path tracked
* **`/cellulo_node_xx_xx/Shutdown`** ([std_msgs/Empty])

	Shuts down the robot

* **`/cellulo_node_xx_xx/ClearTracking`** ([std_msgs/Empty])

	Clears the pose/position/velocity/trajectory goals

* **`/cellulo_node_xx_xx/ClearHapticFeedback`** ([std_msgs/Empty])

	Clears the haptic feedback

* **`/cellulo_node_xx_xx/vibrateOnMotion`** ([ros_cellulo/cellulo_vibrateOnMotion])

	Sets the vibration on motion with iCoef for a given period

* **`/cellulo_node_xx_xx/setGestureEnabled`** ([std_msgs/Bool])

	Sets setGestureEnabled

* **`/cellulo_node_xx_xx/setCasualBackdriveAssistEnabled`** ([std_msgs/Bool])

	Sets setCasualBackdriveAssistEnabled



#### Services

* **`get_state`** ([ros_cellulo/CelluloState])

	Returns the state of the robot: - pose (x,y,theta), veclocities (Vx,Vy,w) , Kidnapped state, KeysTouched, KeysLongTouched.


#### Parameters

* **`scale`** (string, default: 1)

	The scale used: scale =1 means the position unit is mm, scale=0.001 means unit is in meters.

#### To use QT Creator as IDE :

- 1- open qt Creator   
- 2- File -> Open file or project   
- 3- Choose catkin_ws/src/ros_cellulo/CmakeLists.txt  
- 4- Go to Projects tab, change the build directory to catkin_ws/build/ros_cellulo   
- 5- Make sure that the cmake prefix path is defined as:   
CMAKE_PREFIX_PATH: /opt/Qt/5.8/gcc_64;/opt/ros/kinetic/;/home/user/catkin_ws/devel/  
- 6- Now you can run the cmake/build/ and debug in Qt Creator   

* **`Note:`** CelluloRobot folder (from the Cellulo qml) is copied in the include folder so it should be included in catkin_ws/src/ros_cellulo/include



#### TODO
- [ ] add haptic functionalities
- [ ] remove the include of Cellulo Robot and use ENV variable to point to the cellulo plugin lib



#### References

ros package template was used from : https://github.com/ethz-asl/ros_best_practices.git
