#include "ros_cellulo/RosCellulo.hpp"
#include "std_msgs/Time.h"
#include "ros_cellulo/cellulo_pose_velocity.h"
#include "ros_cellulo/cellulo_visual_effect.h"
#include "ros_cellulo/cellulo_kidnapped_msg.h"
#include "ros_cellulo/cellulo_touch_key.h"
#include "ros_cellulo/cellulo_vibrateOnMotion.h"
#include "ros_cellulo/cellulo_simpleVibrate.h"
#include "ros_cellulo/CelluloState.h"
#include <tf2/LinearMath/Quaternion.h>
#include <tf2_ros/transform_broadcaster.h>
#include <geometry_msgs/TransformStamped.h>
#include "std_msgs/Bool.h"
#include "std_msgs/Int8.h"
#include "std_msgs/UInt8.h"
#include "std_msgs/Int32.h"
#include "std_msgs/Float32.h"
#include "std_msgs/Float64.h"
#include "std_msgs/String.h"
#include <cstring>
#include <visualization_msgs/Marker.h>
#include <math.h>
#include <string>
#include <iostream>
#include <fstream>
#include <sys/time.h>
#include <cstdio>


namespace ros_cellulo {

RosCellulo::RosCellulo(ros::NodeHandle& nodeHandle,char* MacAddr) : nodeHandle_(nodeHandle)
{

        if (!readParameters()) {

                ROS_ERROR("Could not read parameters :(.");
                ros::requestShutdown();
        }

        //subscribers
        subscriber_VisEff = nodeHandle_.subscribe(subscriberTopic_VisEff, 1, &RosCellulo::topicCallback_set_Visual_Effect, this);

        subscriber_setLEDResponseMode = nodeHandle_.subscribe(subscriberTopic_setLEDResponseMode, 1, &RosCellulo::topicCallback_setLEDResponseMode, this);

        subscriber_setGoalPose = nodeHandle_.subscribe(subscriberTopic_setGoalPose, 1, &RosCellulo::topicCallback_setGoalPose, this);

        subscriber_setGoalPosition = nodeHandle_.subscribe(subscriberTopic_setGoalPosition, 1, &RosCellulo::topicCallback_setGoalPosition, this);

        subscriber_setGoalXCoordinate = nodeHandle_.subscribe(subscriberTopic_setGoalXCoordinate, 1, &RosCellulo::topicCallback_setGoalXCoordinate, this);

        subscriber_setGoalYCoordinate = nodeHandle_.subscribe(subscriberTopic_setGoalYCoordinate, 1, &RosCellulo::topicCallback_setGoalYCoordinate, this);

        subscriber_setGoalOrientation = nodeHandle_.subscribe(subscriberTopic_setGoalOrientation, 1, &RosCellulo::topicCallback_setGoalOrientation, this);

        subscriber_Reset = nodeHandle_.subscribe(subscriberTopic_Reset, 1, &RosCellulo::topicCallback_reset, this);

        subscriber_ClearTracking = nodeHandle_.subscribe(subscriberTopic_ClearTracking, 1, &RosCellulo::topicCallback_ClearTracking, this);

        subscriber_Traj = nodeHandle_.subscribe(subscriberTopic_Traj, 1, &RosCellulo::topicCallback_follow_Trajectory, this);

        subscriber_fillPath= nodeHandle_.subscribe(subscriberTopic_fillPath, 1, &RosCellulo::topicCallback_fill_Path, this);

        subscriber_shutDown= nodeHandle_.subscribe(subscriberTopic_shutDown, 1, &RosCellulo::topicCallback_shutDown, this);

        subscriber_ClearHapticFeedback = nodeHandle_.subscribe(subscriberTopic_ClearHapticFeedback, 1, &RosCellulo::topicCallback_ClearHapticFeedback, this);

        subscriber_vibrateOnMotion = nodeHandle_.subscribe(subscriberTopic_vibrateOnMotion, 1, &RosCellulo::topicCallback_vibrateOnMotion, this);

        subscriber_simpleVibrate = nodeHandle_.subscribe(subscriberTopic_simpleVibrate, 1, &RosCellulo::topicCallback_simpleVibrate, this);

        subscriber_setGestureEnabled = nodeHandle_.subscribe(subscriberTopic_setGestureEnabled, 1, &RosCellulo::topicCallback_setGestureEnabled, this);

        subscriber_setCasualBackdriveAssistEnabled = nodeHandle_.subscribe(subscriberTopic_setCasualBackdriveAssistEnabled, 1, &RosCellulo::topicCallback_setCasualBackdriveAssistEnabled, this);


        //Publishers
        publisher_TouchKey = nodeHandle_.advertise<cellulo_touch_key>(publisherTopic_TouchKey, 10);
        publisher_LongTouchKey = nodeHandle_.advertise<cellulo_touch_key>(publisherTopic_LongTouchKey, 10);
        publisher_Kidnapped = nodeHandle_.advertise<cellulo_kidnapped_msg>(publisherTopic_Kidnapped, 10);
        publisher_ConnectionStatus = nodeHandle_.advertise<std_msgs::Int8>(publisherTopic_ConnectStatus, 10);
        publisher_LocalAdapterMacAddress = nodeHandle_.advertise<std_msgs::String>(publisherTopic_LocalAdapterAdress, 10);
        publisher_autoConnect = nodeHandle_.advertise<std_msgs::Bool>(publisherTopic_autoConnect, 10);
        publisher_BatteryState = nodeHandle_.advertise<std_msgs::Int8>(publisherTopic_BatteryState, 10);
        publisher_Gesture = nodeHandle_.advertise<std_msgs::Int8>(publisherTopic_Gesture, 10);
        publisher_lastTimestamp = nodeHandle_.advertise<std_msgs::Int8>(publisherTopic_lastTimestamp, 10);
        publisher_framerate = nodeHandle_.advertise<std_msgs::Float32>(publisherTopic_framerate, 10);
        publisher_cameraImageProgress = nodeHandle_.advertise<std_msgs::Float32>(publisherTopic_cameraImageProgress, 10);
        publisher_vx = nodeHandle_.advertise<std_msgs::Float64>(publisherTopic_vx, 10);
        publisher_vy = nodeHandle_.advertise<std_msgs::Float64>(publisherTopic_vy, 10);
        publisher_w = nodeHandle_.advertise<std_msgs::Float64>(publisherTopic_w, 10);
        publisher_poseVelControlEnabled = nodeHandle_.advertise<std_msgs::Bool>(publisherTopic_poseVelControlEnabled, 10);
        publisher_poseVelControlPeriod = nodeHandle_.advertise<std_msgs::Int32>(publisherTopic_poseVelControlPeriod, 10);
        publisher_marker_robot = nodeHandle_.advertise<visualization_msgs::Marker>(publisherTopic_marker_robot, 10);
        publisher_marker_traj = nodeHandle_.advertise<visualization_msgs::Marker>(publisherTopic_marker_traj, 10);
        publisher_marker_traj2 = nodeHandle_.advertise<visualization_msgs::Marker>("redo_traj", 10);
        publisher_destination_reached = nodeHandle_.advertise<std_msgs::Bool>(publisherTopic_destination_reached, 10);


        //Services
        serviceServer_ = nodeHandle_.advertiseService("get_state",&RosCellulo::serviceCallback, this);

        //Link the object to the unique Mac Address
        RosCellulo::setMacAddr(MacAddr);
        RosCellulo::setAutoConnect(1);

        //RESET THE ROBOT
        RosCellulo::reset_counter=0;
        RosCellulo::reset();

        //connect signals to publisher
        connect(this,SIGNAL(keysTouchedChanged()),SLOT(Publish_Keys()));
        connect(this,SIGNAL(keysLongTouchedChanged()),SLOT(Publish_LongKeys()));
        connect(this,SIGNAL(kidnappedChanged()),SLOT(Publish_Kidnapped()));
        connect(this,SIGNAL(connectionStatusChanged()),SLOT(Publish_ConnectionStatus()));
        connect(this,SIGNAL(autoConnectChanged()),SLOT(Publish_autoConnect()));
        connect(this,SIGNAL(macAddrChanged()),SLOT(Publish_macAddress()));
        connect(this,SIGNAL(batteryStateChanged()),SLOT(Publisher_BatteryState()));
        connect(this,SIGNAL(gestureChanged()),SLOT(Publish_Gesture()));
        connect(this,SIGNAL(timestampChanged()),SLOT(Publish_lastTimestamp()));
        connect(this,SIGNAL(timestampChanged()),SLOT(Publish_framerate()));
        connect(this,SIGNAL(cameraImageProgressChanged()),SLOT(Publish_cameraImageProgress()));
        connect(this,SIGNAL(poseChanged(qreal,qreal,qreal)),SLOT(Publish_Pose()));
        connect(this,SIGNAL(vxywChanged()),SLOT(Publish_Vx()));
        connect(this,SIGNAL(vxywChanged()),SLOT(Publish_Vy()));
        connect(this,SIGNAL(vxywChanged()),SLOT(Publish_w()));
        connect(this,SIGNAL(poseVelControlEnabledChanged()),SLOT(Publish_poseVelControlEnable()));
        connect(this,SIGNAL(poseVelControlPeriodChanged()),SLOT(Publish_poseVelControlPeriod()));
        connect(this,SIGNAL(trackingGoalReached()),SLOT(Publish_destinationReached()));
        connect(this,SIGNAL(ready_for_next_pose()),SLOT(go_to_next_point()));
        connect(this,SIGNAL(poseChanged(qreal,qreal,qreal)),SLOT(keep_track()));

}

RosCellulo::~RosCellulo(){
}

bool RosCellulo::readParameters()
{
        if (!nodeHandle_.getParam("scale_coord", scale)) return false;
        return true;
}

void RosCellulo::topicCallback_set_Visual_Effect(const cellulo_visual_effect& message)
{
        //ROS_INFO("Setting Visual Effect ");
        color.setBlue(message.blue);
        color.setGreen(message.green);
        color.setRed(message.red);
        CelluloBluetoothEnums::VisualEffect effect= static_cast<CelluloBluetoothEnums::VisualEffect>(message.effect);
        RosCellulo::setVisualEffect(effect,color,message.value);

}

void RosCellulo::topicCallback_setLEDResponseMode(const std_msgs::UInt8 mode)
{
        /** LEDs respond to touches by slightly increasing brightness    LEDResponseModeResponsiveIndividual = 0  */
        /** LEDs don't respond to touches
           LEDResponseModeAbsolute = 1  */
        /** LEDs respond to hold by all changing color
           LEDResponseModeResponsiveHold = 2  */

        CelluloBluetoothEnums::LEDResponseMode ledMode = static_cast<CelluloBluetoothEnums::LEDResponseMode>(mode.data);
        RosCellulo::setLEDResponseMode(ledMode);

}


void RosCellulo::topicCallback_setGoalPose(const cellulo_pose_velocity& message)
{
        RosCellulo::setPoseVelControlEnabled(1);
        RosCellulo::setGoalPoseAndVelocity(message.Position.x,message.Position.y,message.Position.z,message.Velocity.x,message.Velocity.y,message.Velocity.z,message.xEnabled,message.yEnabled,message.thetaEnabled);
}

void RosCellulo::topicCallback_setGoalVelocity(const geometry_msgs::Vector3 &velocity){
        RosCellulo::setGoalVelocity(velocity.x,velocity.y,velocity.z);
}


void RosCellulo::topicCallback_setGoalPosition(const geometry_msgs::Pose2D &position)
{
        //ROS_INFO("%lf %lf ",pose.x,pose.y);
        //pose.z includes the desired target speed
        RosCellulo::setGoalPosition(position.x,position.y,position.theta);

}

void RosCellulo::topicCallback_setGoalXCoordinate(const cellulo_coord &message)
{
        RosCellulo::setGoalXCoordinate(message.value, message.velocity);

}

void RosCellulo::topicCallback_setGoalYCoordinate(const cellulo_coord &message)
{
        RosCellulo::setGoalYCoordinate(message.value, message.velocity);

}

void RosCellulo::topicCallback_setGoalOrientation(const cellulo_coord &message)
{
        RosCellulo::setGoalOrientation(message.value, message.velocity);

}

void RosCellulo::topicCallback_vibrateOnMotion(const cellulo_vibrateOnMotion& message )
{

        RosCellulo::vibrateOnMotion(message.iCoeff,message.period);

}


void RosCellulo::topicCallback_simpleVibrate(const cellulo_simpleVibrate& message )
{

        RosCellulo::simpleVibrate(message.pose.x,message.pose.y, message.pose.theta, message.period, message.duration);

}

void RosCellulo::topicCallback_setGestureEnabled(const std_msgs::Bool &message )
{

        RosCellulo::setGestureEnabled(message.data);

}

void RosCellulo::topicCallback_setCasualBackdriveAssistEnabled(const std_msgs::Bool &message )
{

        RosCellulo::setCasualBackdriveAssistEnabled(message.data);

}


void RosCellulo::topicCallback_fill_Path(const geometry_msgs::Point &point)
{
        if(RosCellulo::getConnectionStatus()==CelluloBluetoothEnums::ConnectionStatusConnected) {
                RosCellulo::mypath.append(QVector2D(point.x,point.y));
                //ROS_INFO("my path length: %d ",RosCellulo::mypath.length());

                // point.z=1 means it is the first point and we should start tracking it.
                if(point.z==1)
                {   RosCellulo::go_to_next_point();
                    //ROS_INFO("my path length: %d ",RosCellulo::mypath.length());
                }
        }
}

void RosCellulo::Publish_Pose()
{

        //ROS_INFO("broadcasting my pose.");
        static tf2_ros::TransformBroadcaster br;
        geometry_msgs::TransformStamped transformStamped;
        transformStamped.header.stamp = ros::Time::now();
        transformStamped.header.frame_id = "paper_world";
        transformStamped.child_frame_id = RosCellulo::getMacAddr().toStdString().substr(12,5);
        transformStamped.transform.translation.x = RosCellulo::getX()*scale;
        transformStamped.transform.translation.y = RosCellulo::getY()*scale;
        transformStamped.transform.translation.z = 0.0;
        tf2::Quaternion q;
        q.setRPY(0, 0,  RosCellulo::getTheta()/180*M_PI);
        transformStamped.transform.rotation.x = q.x();
        transformStamped.transform.rotation.y = q.y();
        transformStamped.transform.rotation.z = q.z();
        transformStamped.transform.rotation.w = q.w();

        br.sendTransform(transformStamped);

        /* Display a cube to visulize cellulo robot */
        visualization_msgs::Marker points;
        visualization_msgs::Marker robot;
        points.header.frame_id = robot.header.frame_id =RosCellulo::getMacAddr().toStdString().substr(12,5);
        points.header.stamp = robot.header.stamp =ros::Time::now();
        points.action =robot.action=visualization_msgs::Marker::ADD;
        points.ns=robot.ns="ros_cellulo";
        points.pose.orientation.w = robot.pose.orientation.w=1.0;
        points.id = f;
        robot.id=0;
        points.type = visualization_msgs::Marker::SPHERE;
        robot.type = visualization_msgs::Marker::MESH_RESOURCE;

        // POINTS markers use x and y scale for width/height respectively
        robot.scale.x = scale;
        robot.scale.y = scale;
        robot.scale.z = scale;

        points.scale.x = 20*scale;
        points.scale.y = 20*scale;
        points.scale.z = 20*scale;

        // Points are green
        points.color.r = 1.0f;
        points.color.a = 1.0;
        points.lifetime=ros::Duration(20);

        robot.color.r = color.redF();
        robot.color.g = color.greenF();
        robot.color.b = color.blueF();
        robot.color.a = 1.0;
        robot.lifetime=ros::Duration(20);

        points.pose.position.x=0;
        points.pose.position.y=0;
        points.pose.position.z=0;

        robot.pose.position.x=0;
        robot.pose.position.y=0;
        robot.pose.position.z=0;

        f=f%1000+1; //display points of the trajectory up to 1000 points


        robot.mesh_resource = "package://ros_cellulo/meshes/cellulo.STL";
        //ROS_INFO("%d",f);
        publisher_marker_robot.publish(robot);
        publisher_marker_traj.publish(points);
}






bool RosCellulo::serviceCallback(CelluloState::Request& request,
                                 CelluloState::Response& response)
{

        ROS_INFO("Sending the robot state ");
        response.Position.header.stamp = ros::Time::now();
        response.Position.header.frame_id = "paper_world";
        response.Position.child_frame_id = RosCellulo::getMacAddr().toStdString().substr(12,5);
        response.Position.transform.translation.x = RosCellulo::getX();
        response.Position.transform.translation.y = RosCellulo::getY();
        response.Position.transform.translation.z = 0.0;

        tf2::Quaternion q;
        q.setRPY(0, 0,  RosCellulo::getTheta()/180*M_PI);
        response.Position.transform.rotation.x = q.x();
        response.Position.transform.rotation.y = q.y();
        response.Position.transform.rotation.z = q.z();
        response.Position.transform.rotation.w = q.w();

        response.vx.data=RosCellulo::getVx();
        response.vy.data=RosCellulo::getVy();
        response.w.data=RosCellulo::getW();

        response.kidnapped=RosCellulo::getKidnapped();

        int i;
        for (i=0; i<6; i++)
        {
                response.keysTouched.push_back(RosCellulo::getKeysTouched()[i]);
                response.keysLongTouched.push_back(RosCellulo::getKeysLongTouched()[i]);
        }

        return true;
}

void RosCellulo::Publish_Keys()
{

        cellulo_touch_key keys;
        int i;
        for (i=0; i<6; i++)
        {
                keys.keysTouched.push_back(RosCellulo::getKeysTouched()[i]);
        }
        keys.timestamp=ros::Time::now();
        //ROS_INFO("Publish Keys ");
        publisher_TouchKey.publish(keys);
}

void RosCellulo::Publish_LongKeys()
{

        cellulo_touch_key keys; //= new cellulo_touch_key[6];
        int i;
        for (i=0; i<6; i++)
        {
                keys.keysTouched.push_back(RosCellulo::getKeysLongTouched()[i]);
        }
        keys.timestamp=ros::Time::now();
        //ROS_INFO("Publish Long Keys ");
        publisher_LongTouchKey.publish(keys);
}

void RosCellulo::Publish_Kidnapped(){

        cellulo_kidnapped_msg kidnapped;
        kidnapped.Kidnapped=RosCellulo::getKidnapped();
        kidnapped.header.frame_id=RosCellulo::getMacAddr().toStdString().substr(12,5);
        kidnapped.header.stamp= ros::Time::now();
        publisher_Kidnapped.publish(kidnapped);
}

void RosCellulo::Publish_ConnectionStatus(){

        std_msgs::Int8 connecSt;
        connecSt.data=RosCellulo::getConnectionStatus();
        publisher_ConnectionStatus.publish(connecSt);
}
void RosCellulo::Publish_LocalAdapterMacAddress(){

        std_msgs::String LocalAdapMacAd;
        LocalAdapMacAd.data= RosCellulo::getLocalAdapterMacAddr().toStdString();
        publisher_LocalAdapterMacAddress.publish(LocalAdapMacAd);
}

void RosCellulo::Publish_autoConnect(){

        std_msgs::Bool autoCon;
        autoCon.data=RosCellulo::getAutoConnect();
        publisher_autoConnect.publish(autoCon);
}

void RosCellulo::Publish_macAddress(){

        std_msgs::String macAd;
        macAd.data=RosCellulo::getMacAddr().toStdString();
        publisher_macAddress.publish(macAd);
        ROS_INFO("mac address is %s \n", macAd.data.c_str());
}

void RosCellulo::Publisher_BatteryState(){

        std_msgs::Int8 BatState;
        BatState.data=RosCellulo::getBatteryState();
        publisher_BatteryState.publish(BatState);
}

void RosCellulo::Publish_Gesture(){

        std_msgs::Int8 gest;
        gest.data=RosCellulo::getGesture();
        publisher_Gesture.publish(gest);
}


void RosCellulo::Publish_lastTimestamp(){

        std_msgs::Int8 lastTimeStamp;
        lastTimeStamp.data=RosCellulo::getLastTimestamp();


        publisher_lastTimestamp.publish(lastTimeStamp);
}

void RosCellulo::Publish_framerate(){

        std_msgs::Float32 frameRate;
        frameRate.data=RosCellulo::getFramerate();
        publisher_framerate.publish(frameRate);
}

void RosCellulo::Publish_cameraImageProgress(){
        std_msgs::Float32 CameraImageProgress;
        CameraImageProgress.data=RosCellulo::getCameraImageProgress();

        publisher_cameraImageProgress.publish(CameraImageProgress);
}

void RosCellulo::Publish_Vx(){
        std_msgs::Float64 vx;
        vx.data=RosCellulo::getVx();

        publisher_vx.publish(vx);
}

void RosCellulo::Publish_Vy(){
        std_msgs::Float64 vy;
        vy.data=RosCellulo::getVy();

        publisher_vy.publish(vy);
}

void RosCellulo::Publish_w(){
        std_msgs::Float64 w;
        w.data=RosCellulo::getW();
        publisher_w.publish(w);

}

void RosCellulo::Publish_poseVelControlEnable(){
        std_msgs::Bool e;
        e.data=RosCellulo::getPoseVelControlEnabled();

        publisher_poseVelControlEnabled.publish(e);
}

void RosCellulo::Publish_poseVelControlPeriod(){
        std_msgs::Int32 p;
        p.data=RosCellulo::getPoseVelControlPeriod();

        publisher_poseVelControlPeriod.publish(p);
}
void RosCellulo::topicCallback_ClearTracking(const std_msgs::Empty message){
        RosCellulo::clearTracking();
}

void RosCellulo::topicCallback_ClearHapticFeedback(const std_msgs::Empty message){
        RosCellulo::clearHapticFeedback();
}

void RosCellulo::topicCallback_reset(const std_msgs::Empty message)
{
        RosCellulo::reset_counter=0;
        RosCellulo::reset_robot();

}

bool RosCellulo::reset_robot(){
        if(RosCellulo::getConnectionStatus()==CelluloBluetoothEnums::ConnectionStatusConnected)
        {
                RosCellulo::reset();
                RosCellulo::mypath.clear();
                RosCellulo::my_tracked_position=QVector2D(-1,-1);
                ROS_INFO("resetting");
                return true;
        }
        return false;
}

void RosCellulo::topicCallback_shutDown(const std_msgs::Empty &empt)
{

        RosCellulo::shutdown();
}
void RosCellulo::Publish_destinationReached(){
        std_msgs::Bool dest;
        dest.data=true;
        publisher_destination_reached.publish(dest);
}

void RosCellulo::topicCallback_follow_Trajectory(const nav_msgs::Path &path)
{
        int i=0;
        int len=path.poses.size();
        RosCellulo::clearTracking();
        ROS_INFO("Following the traj: %d poses",len);
        visualization_msgs::Marker points;
        points.header.frame_id = "paper_world";
        points.header.stamp = ros::Time::now();
        points.action =visualization_msgs::Marker::ADD;
        points.ns="ros_cellulo";
        points.pose.orientation.w = 1.0;
        points.id = 102598725;
        points.type = visualization_msgs::Marker::LINE_STRIP;

        // POINTS markers use x and y scale for width/height respectively
        points.scale.x = 0.001;

        // Points are green
        points.color.g = 1.0f;
        points.color.a = 1.0;
        points.lifetime=ros::Duration();

        for(i=0; i<len; i=i+1)
        {

                // POINTS markers use x and y scale for width/height respectively
                points.scale.x = 0.001;

                // Points are green
                points.color.g = 1.0f;
                points.color.a = 1.0;
                points.lifetime=ros::Duration();

                RosCellulo::mypath.append(QVector2D(path.poses[i].pose.position.x, path.poses[i].pose.position.y));

                geometry_msgs::Point p;
                p.x=path.poses[i].pose.position.x*scale;
                p.y=path.poses[i].pose.position.y*scale;
                p.z=0;
                points.points.push_back(p);

        }

        publisher_marker_traj2.publish(points);
        RosCellulo::go_to_next_point();
}

void RosCellulo::go_to_next_point(){

        //ROS_INFO("go to next point %lf", RosCellulo::my_previous_dist);
        if(!RosCellulo::mypath.isEmpty())
        {
                //ROS_INFO("taking first point");
                QVector2D point=RosCellulo::mypath.takeFirst();
                my_tracked_position=point;
                RosCellulo::setGoalPosition(point.x(),point.y(),150);
        }
        else
        {
                //ROS_INFO("I am done ");
                RosCellulo::setVisualEffect(CelluloBluetoothEnums::VisualEffectAlertAll,QColor(0, 255, 0),0);
                RosCellulo::clearTracking();
        }
}



void RosCellulo::keep_track()
{
        if(!RosCellulo::mypath.isEmpty())
        {

                QVector2D mydest=RosCellulo::my_tracked_position;
                double x=mydest.x()-RosCellulo::getX();
                double y=mydest.y()-RosCellulo::getY();
                double dist=norm(x,y); //distance to my destination

                //ROS_INFO("my dist from goal is: %lf",dist);

                if (mydest.x()!=-1)
                        RosCellulo::setGoalVelocity(135*x/dist,135*y/dist,0);
                if (dist<23)
                        emit ready_for_next_pose();
        }
}

double RosCellulo::norm(double x,double y)
{
        return sqrt(pow(x,2)+pow(y,2));
}


} /* namespace */
